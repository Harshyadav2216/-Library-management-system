from flask import Flask, render_template, request, redirect, flash, url_for, jsonify
from flask_migrate import Migrate
from models import db, Book, Member, Stock, Transaction, Charges
import datetime
import requests
from sqlalchemy import desc
from sqlalchemy.exc import IntegrityError

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///library.db'
app.config['SECRET_KEY'] = 'af9d4e10d142994285d0c1f861a70925'
db.init_app(app)
migrate = Migrate(app, db)

# Calculate total earnings (all-time rent from returned books)
def calculate_total_earnings():
    total_earnings = db.session.query(db.func.sum(Transaction.rent_fee)).filter(
        Transaction.return_date != None).scalar()
    return total_earnings if total_earnings else 0

# Calculate total rent for current month
def calculate_total_rent_current_month():
    current_month = datetime.datetime.now().month
    current_year = datetime.datetime.now().year
    start_date = datetime.datetime(current_year, current_month, 1)
    end_date = datetime.datetime(current_year, current_month + 1, 1) - datetime.timedelta(days=1)
    total_rent = db.session.query(db.func.sum(Transaction.rent_fee)).filter(
        Transaction.return_date != None,
        Transaction.return_date >= start_date,
        Transaction.return_date <= end_date).scalar()
    return total_rent if total_rent else 0

# Home route to show dashboard
@app.route('/')
def index():
    borrowed_books = db.session.query(Transaction).filter(Transaction.return_date == None).count()
    total_books = Book.query.count()
    total_members = Member.query.count()
    total_rent_current_month = calculate_total_rent_current_month()
    total_earnings = calculate_total_earnings()
    recent_transactions = db.session.query(Transaction, Book).join(Book).order_by(Transaction.issue_date.desc()).limit(5).all()
    return render_template('index.html', borrowed_books=borrowed_books, total_books=total_books,
                           total_members=total_members, recent_transactions=recent_transactions,
                           total_rent_current_month=total_rent_current_month, total_earnings=total_earnings)

# Calculate debt for a member
def calculate_dbt(member):
    if not member:
        print("No member provided, returning debt 0")
        return 0
    dbt = 0
    charge = db.session.query(Charges).first()
    if not charge or charge.rentfee is None:
        print(f"No charge found or rentfee is None for member {member.id}")
        return 0
    transactions = db.session.query(Transaction).filter_by(member_id=member.id, return_date=None).all()
    for transaction in transactions:
        days_difference = (datetime.date.today() - transaction.issue_date.date()).days
        if days_difference > 0:
            dbt += days_difference * charge.rentfee
    print(f"Calculated debt for member {member.id}: {dbt}")
    return dbt if dbt is not None else 0

# Add a new book
@app.route('/add_book', methods=['GET', 'POST'])
def add_book():
    if request.method == 'POST':
        title = request.form.get('title')
        author = request.form.get('author')
        isbn = request.form.get('isbn')
        publisher = request.form.get('publisher')
        page = request.form.get('page')
        stock = request.form.get('stock')
        try:
            new_book = Book(title=title, author=author, isbn=isbn, publisher=publisher, page=page)
            db.session.add(new_book)
            db.session.flush()
            new_stock = Stock(book_id=new_book.id, total_quantity=stock, available_quantity=stock)
            db.session.add(new_stock)
            db.session.commit()
            flash('Book added successfully!', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            db.session.rollback()
            flash(f"Error adding book: {e}", 'error')
    return render_template('add_book.html')

# Add a new member
@app.route('/add_member', methods=['GET', 'POST'])
def add_member():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        address = request.form.get('address')
        try:
            new_member = Member(name=name, email=email, phone=phone, address=address)
            db.session.add(new_member)
            db.session.commit()
            flash('Member added successfully!', 'success')
            return redirect(url_for('add_member'))
        except Exception as e:
            db.session.rollback()
            flash(f"Error adding member: {e}", 'error')
    return render_template('add_member.html')

# View all books
@app.route('/view_books', methods=['GET', 'POST'])
def book_list():
    if request.method == 'POST':
        title = request.form.get('searcht')
        author = request.form.get('searcha')
        if title and author:
            books = db.session.query(Book, Stock).join(Stock).filter(
                Book.title.like(f'%{title}%'), Book.author.like(f'%{author}%')).all()
        elif title:
            books = db.session.query(Book, Stock).join(Stock).filter(Book.title.like(f'%{title}%')).all()
        elif author:
            books = db.session.query(Book, Stock).join(Stock).filter(Book.author.like(f'%{author}%')).all()
        else:
            books = db.session.query(Book, Stock).join(Stock).all()
    else:
        books = db.session.query(Book, Stock).join(Stock).all()
    return render_template('view_books.html', books=books)

# View all members
@app.route('/view_members', methods=['GET', 'POST'])
def member_list():
    if request.method == 'POST':
        search = request.form.get('search')
        members = db.session.query(Member).filter(Member.name.like(f'%{search}%')).all()
    else:
        members = db.session.query(Member).all()
    return render_template('view_members.html', member=members)

# Edit a book
@app.route('/edit_book/<int:id>', methods=['GET', 'POST'])
def edit_book(id):
    book = Book.query.get(id)
    stock = Stock.query.get(book.id) if book else None
    if request.method == 'POST':
        try:
            book.title = request.form.get('title')
            book.author = request.form.get('author')
            book.isbn = request.form.get('isbn')
            book.publisher = request.form.get('publisher')
            book.page = request.form.get('page')
            if stock:
                stock.total_quantity = request.form.get('stock')
            db.session.commit()
            flash("Updated successfully", 'success')
        except Exception as e:
            db.session.rollback()
            flash(f"An error occurred: {e}", 'error')
    return render_template('edit_book.html', book=book, stock=stock)

# Edit a member
@app.route('/edit_member/<int:id>', methods=['GET', 'POST'])
def edit_member(id):
    member = Member.query.get(id)
    if request.method == 'POST':
        try:
            member.name = request.form.get('name')
            member.phone = request.form.get('phone')
            member.email = request.form.get('email')
            member.address = request.form.get('address')
            db.session.commit()
            flash("Updated successfully", 'success')
        except Exception as e:
            db.session.rollback()
            flash(f"An error occurred: {e}", 'error')
    return render_template('edit_member.html', member=member)

# Delete a member
@app.route('/delete_member/<int:id>', methods=['GET', 'POST'])
def delete_member(id):
    try:
        member = Member.query.get(id)
        db.session.delete(member)
        db.session.commit()
        flash("Member removed successfully", 'success')
    except Exception as e:
        db.session.rollback()
        flash(f"An error occurred: {e}", 'error')
    return redirect('/view_members')

# Delete a book
@app.route('/delete_book/<int:id>', methods=['GET', 'POST'])
def delete_book(id):
    try:
        book = Book.query.get(id)
        stock = Stock.query.get(book.id)
        db.session.delete(book)
        db.session.delete(stock)
        db.session.commit()
        flash("Book removed successfully", 'success')
    except Exception as e:
        db.session.rollback()
        flash(f"An error occurred: {e}", 'error')
    return redirect('/view_books')

# View book details
@app.route('/view_book/<int:id>')
def view_book(id):
    book = Book.query.get(id)
    stock = Stock.query.filter_by(book_id=id).first()
    transactions = Transaction.query.filter_by(book_id=id).all()
    return render_template('view_book.html', book=book, trans=transactions, stock=stock)

# View member details
@app.route('/view_member/<int:id>')
def view_member(id):
    member = Member.query.get(id)
    transactions = Transaction.query.filter_by(member_id=member.id).all()
    dbt = calculate_dbt(member) or 0
    print(f"Debt for member {id}: {dbt}")
    return render_template('view_member.html', member=member, trans=transactions, debt=dbt)

# Issue a book
@app.route('/issuebook', methods=['GET', 'POST'])
def issue_book():
    book = None
    mem = None
    dbt = 0
    if request.method == 'POST':
        memberid = request.form.get('mk')
        title = request.form.get('bk')
        if not memberid or not title:
            flash("Please provide valid member ID and book title.", 'error')
            return render_template('issue.html', book=None, member=None, debt=0)
        book = db.session.query(Book, Stock).join(Stock).filter(Book.title.like(f'%{title}%')).first() or \
               db.session.query(Book, Stock).join(Stock).filter(Book.id.like(title)).first()
        print(f"Book: {book}")
        mem = db.session.query(Member).get(memberid)
        print(f"Member: {mem}")
        if not book:
            flash("Book not found!", 'error')
            return render_template('issue.html', book=None, member=mem, debt=0)
        if not mem:
            flash("Member not found!", 'error')
            return render_template('issue.html', book=book, member=None, debt=0)
        dbt = calculate_dbt(mem) or 0
        print(f"Debt: {dbt}")
    return render_template('issue.html', book=book, member=mem, debt=dbt)

# Confirm book issuance
@app.route('/issuebookconfirm', methods=['GET', 'POST'])
def issue_book_confirm():
    if request.method == 'POST':
        memberid = request.form.get('memberid')
        bookid = request.form.get('bookid')
        if not memberid or not bookid:
            flash("Invalid member or book ID.", 'error')
            return redirect('/issuebook')
        stock = db.session.query(Stock).filter_by(book_id=bookid).first()
        if not stock or stock.available_quantity <= 0:
            flash("Book is not available for issuance.", 'error')
            return redirect('/issuebook')
        try:
            new_transaction = Transaction(book_id=bookid, member_id=memberid, issue_date=datetime.date.today())
            print(f"New Transaction: {new_transaction}")
            stock.available_quantity -= 1
            stock.borrowed_quantity += 1
            stock.total_borrowed += 1
            db.session.add(new_transaction)
            db.session.commit()
            flash("Transaction added successfully", 'success')
        except Exception as e:
            db.session.rollback()
            flash(f"Error creating transaction: {e}", 'error')
        return redirect('/issuebook')
    return render_template('issue.html')

# View transactions
@app.route('/transactions', methods=['GET', 'POST'])
def view_borrowings():
    transactions = db.session.query(Transaction, Member, Book).join(Book).join(Member).order_by(
        desc(Transaction.return_date.is_(None))).all()
    if request.method == 'POST':
        search = request.form.get('search')
        transactions_by_name = db.session.query(Transaction, Member, Book).join(Book).join(Member).filter(
            Member.name.like(f'%{search}%')).order_by(desc(Transaction.return_date.is_(None))).all()
        transaction_by_id = db.session.query(Transaction, Member, Book).join(Book).join(Member).filter(
            Transaction.id == search).order_by(desc(Transaction.return_date.is_(None))).all()
        transactions = transactions_by_name or transaction_by_id or []
    return render_template('transactions.html', trans=transactions)

# Return a book
@app.route('/returnbook/<int:id>', methods=['GET'])
def return_book(id):
    transaction = db.session.query(Transaction, Member, Book).join(Book).join(Member).filter(Transaction.id == id).first()
    if not transaction:
        flash("Transaction not found!", 'error')
        return redirect('/transactions')
    if transaction.Transaction.return_date:
        flash("This book has already been returned!", 'error')
        return redirect('/transactions')
    rent = calculate_rent(transaction)
    print(f"Rent for transaction {id}: {rent}")
    return render_template('returnbook.html', trans=transaction, rent=rent)

# Confirm book return
@app.route('/returnbookconfirm', methods=['POST'])
def return_book_confirm():
    if request.method == 'POST':
        id = request.form.get('id')
        if not id:
            flash("Invalid transaction ID!", 'error')
            return redirect('/transactions')
        trans, member = db.session.query(Transaction, Member).join(Member).filter(Transaction.id == id).first()
        if not trans or not member:
            flash("Transaction or member not found!", 'error')
            return redirect('/transactions')
        if trans.return_date:
            flash("This book has already been returned!", 'error')
            return redirect('/transactions')
        stock = Stock.query.filter_by(book_id=trans.book_id).first()
        charge = Charges.query.first()
        if not charge or charge.rentfee is None:
            flash("Charge configuration not found! Please set up charges.", 'error')
            return redirect('/transactions')
        try:
            rent = (datetime.date.today() - trans.issue_date.date()).days * charge.rentfee
            if rent < 0:
                rent = 0
            if stock:
                stock.available_quantity += 1
                stock.borrowed_quantity -= 1
            else:
                flash("Stock information not found!", 'error')
                return redirect('/transactions')
            trans.return_date = datetime.date.today()
            trans.rent_fee = rent
            db.session.commit()
            flash(f"{member.name} returned book successfully with rent fee {rent} ₹", 'success')
        except Exception as e:
            db.session.rollback()
            flash(f"Error processing return: {e}", 'error')
    return redirect('/transactions')

# Calculate rent for a transaction
def calculate_rent(transaction):
    charge = Charges.query.first()
    if not charge or charge.rentfee is None:
        print("No charge found or rentfee is None, returning rent 0")
        return 0
    days = (datetime.date.today() - transaction.Transaction.issue_date.date()).days
    rent = days * charge.rentfee
    return rent if rent >= 0 else 0

# Set book charges
@app.route('/set_charges', methods=['GET', 'POST'])
def set_charges():
    charge = Charges.query.first()
    if request.method == 'POST':
        rentfee = request.form.get('rentfee', type=int)
        if rentfee is None or rentfee < 0:
            flash("Please enter a valid rental fee (₹ per day, whole number).", 'error')
            return render_template('set_charges.html', charge=charge)
        try:
            if charge:
                charge.rentfee = rentfee
            else:
                charge = Charges(rentfee=rentfee)
                db.session.add(charge)
            db.session.commit()
            flash(f"Rental fee set to ₹{rentfee} per day successfully!", 'success')
            return redirect(url_for('set_charges'))
        except Exception as e:
            db.session.rollback()
            flash(f"Error setting charges: {e}", 'error')
    return render_template('set_charges.html', charge=charge)

# API for importing books
API_BASE_URL = "https://frappe.io/api/method/frappe-library"

@app.route('/import_book', methods=['GET', 'POST'])
def imp():
    if request.method == 'POST':
        title = request.form.get('title', default='', type=str)
        num_books = request.form.get('num_books', default=20, type=int)
        num_pages = (num_books + 19) // 20
        all_books = []
        for page in range(1, num_pages + 1):
            url = f"{API_BASE_URL}?page={page}&title={title}"
            response = requests.get(url)
            data = response.json()
            all_books.extend(data.get('message', []))
        return render_template('imp.html', data=all_books[:num_books], title=title, num_books=num_books)
    return render_template('imp.html', data=[], title='', num_books=20)

# Save imported books
@app.route('/save_all_books', methods=['POST'])
def save_all_books():
    data = request.json
    for book_data in data:
        book_id = book_data['id']
        existing_book = Book.query.get(book_id)
        if existing_book is None:
            try:
                book = Book(
                    id=book_id,
                    title=book_data['title'],
                    author=book_data['authors'],
                    isbn=book_data['isbn'],
                    publisher=book_data['publisher'],
                    page=book_data['numPages']
                )
                st = book_data['stock']
                db.session.add(book)
                stock = Stock(book_id=book_id, total_quantity=st, available_quantity=st)
                db.session.add(stock)
                db.session.commit()
            except IntegrityError as e:
                db.session.rollback()
                print(f"Error adding book with ID {book_id}: {str(e)}")
        else:
            print(f"Book with ID {book_id} already exists, skipping.")
    flash("Books added successfully", 'success')
    return redirect('/import_book')

# Update stock
@app.route('/stockupdate/<int:id>', methods=['GET', 'POST'])
def stock_update(id):
    stock, book = db.session.query(Stock, Book).join(Book).filter(Stock.book_id == id).first()
    if request.method == 'POST':
        qty = int(request.form.get('qty', 0))
        try:
            if qty > 0:
                stock.available_quantity += qty
                stock.total_quantity += qty
            elif qty < 0:
                qty = abs(qty)
                stock.available_quantity -= qty
                stock.total_quantity -= qty
            db.session.commit()
            flash("Stock updated", 'success')
        except Exception as e:
            db.session.rollback()
            flash(f"Error updating stock: {e}", 'error')
    return render_template('stockupdate.html', stock=stock, book=book)

if __name__ == '__main__':
    app.run(debug=True)